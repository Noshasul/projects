// Setting up an empty JS object to act as an endpoint for all routes
logprojectData = {};

// Requiring Express to run the server and routes
const express = require('express');

// Starting up an instance of the app
const app = express();
const router = express.Router();

// Middleware setup
const bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

// Cors for cross-origin allowance
const cors = require('cors');
app.use(cors());

// Initializing the main project folder
app.use(express.static('website'));

// Define a route handler for GET '/all'
const getInfo = (request, response) => response.send(projectData);
app.get('/all', getInfo);

// Define a route handler for POST '/add'
const postInfo = (request, response) => {
    projectData = request.body;
    console.log(projectData);
    response.send(projectData);
}

app.post('/add', postInfo);

// Setup Server
const port = 3031;

// Testing the server 
const server = app.listen(port, listening);
function listening() {
console.log(`Server running at localhost: ${port}`);
}