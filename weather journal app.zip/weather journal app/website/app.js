let d = new Date();
let newDate = d.getMonth()+'.'+ d.getDate()+'.'+ d.getFullYear();

const baseURL = 'https://api.openweathermap.org/data/2.5/weather?zip=';
const apiKey = '&appid=e6b52d8584c0106760a2eb9f72ec6bef&units=metric';

const generateWeather = async () => {
    try {
        const zip = document.getElementById("zip").value;
        const feelings = document.getElementById("feelings").value;

        const data = await getData(zip);
        if (!data) {
            throw new Error("No data received from the API");
        }
        const { main: { temp }, weather } = data;
        const { description } = weather;
        const newDate = new Date().toLocaleDateString();
        const getInfo = {
            newDate,
            temp: Math.round(temp),
            information: description,
            feelings,
        };

        const newData = await postallData('/add', getInfo);
        console.log(newData);

        // Refresh the UI to show the updated data
        retrieveData();
    } catch (error) {
        console.log("Error:", error);
        const errorElement = document.getElementById('error');
        errorElement.innerHTML = error.message;
        setTimeout(() => errorElement.innerHTML = '', 4000);
    }
};

document.getElementById("generate").addEventListener("click", generateWeather);

const getData = async (zip) => {
    try {
        const response = await fetch(baseURL + zip + apiKey);
        if (!response.ok) {
            
        }
        return await response.json();
    } catch (error) {
        console.log(error)
    }
};

const postallData = async (url = '', getInfo = {}) => {
    try {
        const response = await fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(getInfo),
        });
        if (!response.ok) {
            throw new Error('Failed to post data');
        }
        return await response.json();
    } catch (error) {
        console.log("Post Error:", error);
        throw error;
    }
};

const retrieveData = async () => {
        const request = await fetch('/all');
    
        const allData = await request.json()
        console.log(allData)
{
        document.getElementById('date').innerHTML = allData.date;
        document.getElementById('temp').innerHTML = Math.round(allData.temp)+ 'Cْ';
        document.getElementById('content').innerHTML = allData.feelings;
        
        console.log('error', error);
    }
}
