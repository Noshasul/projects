This project is a part of Udacity Front End Developer Nanodegree program.

Description
The aim of this project is to build a multi-section landing page, with a dynamically updating navigational menu based on the amount of content that is added to the page.

Languages used
HTML
CSS
JAVASCRIPT
